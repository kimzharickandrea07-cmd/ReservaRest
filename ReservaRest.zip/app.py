from flask import Flask, render_template, request, redirect, url_for, flash
import psycopg2
from psycopg2.extras import RealDictCursor

app = Flask(__name__)
app.secret_key = 'tu_clave_secreta_reservarest'

# CONFIGURACIÓN CON POSTGRESQL (El elefantito)
def get_db_connection():
    conn = psycopg2.connect(
        host="localhost",
        database="reservarest_db",
        user="postgres",
        password="admin123", # <-- RECUERDA: Pon aquí tu contraseña real de pgAdmin
        client_encoding="utf8"    # <-- SOLUCIONA EL ERROR DE LAS LETRAS (UnicodeDecodeError)
    )
    return conn

# Lista oficial de tus 18 restaurantes inventados con descripciones variadas
RESTAURANTES = [
    {"nombre": "Nebula & Oliva", "desc": "Pastas artesanales y pizzas al horno de leña en un ambiente íntimo y romántico."},
    {"nombre": "Taco Torbellino", "desc": "Auténticos tacos mexicanos con tortillas hechas a mano y salsas picantes."},
    {"nombre": "Koi Lunar", "desc": "Sushi premium y platos asiáticos inspirados en recetas milenarias de oriente."},
    {"nombre": "Fogón de Nube", "desc": "Cortes de carne jugosos e internacionales cocinados lentamente al carbón."},
    {"nombre": "Oliva Azul", "desc": "Mariscos frescos, cazuelas y arroces con la esencia pura del mar Mediterráneo."},
    {"nombre": "Sakura Mist", "desc": "Experiencia japonesa tradicional con shows culinarios de teppanyaki en vivo."},
    {"nombre": "Burguer Lab", "desc": "Hamburguesas gourmet con combinaciones de quesos artesanales e ingredientes locos."},
    {"nombre": "La Terraza Rosa", "desc": "Postres de autor, cafés especiales y un brunch dominical perfecto para fotos."},
    {"nombre": "Aroma y Carbón", "desc": "Platos tradicionales y criollos con el inconfundible sabor hogareño de la abuela."},
    {"nombre": "Bistró París", "desc": "Cafetería y panadería francesa clásica con los mejores croissants y repostería."},
    {"nombre": "Wok del Sol", "desc": "Salteados orientales armados a tu gusto con vegetales seleccionados y frescos."},
    {"nombre": "Rustika Pizzería", "desc": "Masas maduradas por 48 horas e ingredientes orgánicos del campo a tu mesa."},
    {"nombre": "Pampa & Vino", "desc": "Cortes de carne al estilo asado argentino acompañados de una selecta bodega."},
    {"nombre": "Matcha House", "desc": "Especialistas en bebidas saludables, bowls nutritivos y comida balanceada."},
    {"nombre": "Bella Italia", "desc": "El rincón culinario acogedor con las lasañas y pastas más ricas de la ciudad."},
    {"nombre": "Mar y Fuego", "desc": "Ceviches frescos, arroces marineros y cócteles tropicales frente a la playa."},
    {"nombre": "Verde Menta", "desc": "Opciones sabrosas 100% veganas y vegetarianas llenas de frescura y mucho color."},
    {"nombre": "Estación Central", "desc": "Picadas generosas, alitas picantes y cervezas artesanales para compartir juntos."}
]

@app.route('/')
def index():
    return render_template('index.html', restaurantes=RESTAURANTES)

@app.route('/reservar', methods=['GET', 'POST'])
def reservar():
    if request.method == 'POST':
        restaurante = request.form['restaurante']
        nombre = request.form['nombre']
        correo = request.form['correo']
        fecha = request.form['fecha']
        hora = request.form['hora']
        personas = request.form['personas']
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        # VALIDACIÓN: Verificar si ya existe una reserva idéntica para evitar cruces
        cur.execute(
            "SELECT id FROM reservas WHERE restaurante = %s AND fecha = %s AND hora = %s",
            (restaurante, fecha, hora)
        )
        existe = cur.fetchone()
        
        if existe:
            cur.close()
            conn.close()
            flash('¡Lo sentimos! Ya existe una reserva para este restaurante en esa misma fecha y hora. Por favor, elige otro horario.', 'danger')
            return redirect(url_for('reservar'))
        
        # Si está libre, guardamos de inmediato en PostgreSQL
        cur.execute(
            "INSERT INTO reservas (restaurante, nombre_cliente, correo, fecha, hora, numero_personas) VALUES (%s, %s, %s, %s, %s, %s)",
            (restaurante, nombre, correo, fecha, hora, personas)
        )
        conn.commit()
        cur.close()
        conn.close()
        
        flash('Reserva guardada correctamente', 'success')
        return redirect(url_for('mis_reservas'))
        
    return render_template('reservar.html', restaurantes=RESTAURANTES)

@app.route('/mis-reservas')
def mis_reservas():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("SELECT * FROM reservas ORDER BY fecha, hora")
    lista_reservas = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('mis_reservas.html', reservas=lista_reservas)

@app.route('/modificar/<int:id>', methods=['GET', 'POST'])
def modificar_reserva(id):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
    if request.method == 'POST':
        personas = request.form['personas']
        fecha = request.form['fecha']
        hora = request.form['hora']
        
        cur.execute(
            "UPDATE reservas SET numero_personas = %s, fecha = %s, hora = %s WHERE id = %s",
            (personas, fecha, hora, id)
        )
        conn.commit()
        cur.close()
        conn.close()
        flash('Reserva modificada correctamente', 'success')
        return redirect(url_for('mis_reservas'))
        
    cur.execute("SELECT * FROM reservas WHERE id = %s", (id,))
    reserva = cur.fetchone()
    cur.close()
    conn.close()
    return render_template('modificar.html', reserva=reserva)

@app.route('/cancelar/<int:id>', methods=['POST'])
def cancelar_reserva(id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM reservas WHERE id = %s", (id,))
    conn.commit()
    cur.close()
    conn.close()
    flash('Reserva cancelada exitosamente', 'success')
    return redirect(url_for('mis_reservas'))

if __name__ == '__main__':
    app.run(debug=True)
